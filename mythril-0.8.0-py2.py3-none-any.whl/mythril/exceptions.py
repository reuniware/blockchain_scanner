class CompilerError(Exception):
    pass